#include "MainComponent.h"

MainComponent::MainComponent()
{
    addAndMakeVisible(mainGUI);
    setSize(600, 250);
    setAudioChannels(0, 2);
}

MainComponent::~MainComponent()
{
    shutdownAudio();
}

void MainComponent::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    mainGUI.prepareToPlay(samplesPerBlockExpected, sampleRate);
}

void MainComponent::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    mainGUI.getNextAudioBlock(bufferToFill);
}

void MainComponent::releaseResources()
{
    mainGUI.releaseResources();
}

void MainComponent::resized()
{
    mainGUI.setBounds(getLocalBounds());
}