#include "PlayerGUI.h"

PlayerGUI::PlayerGUI()
{
    for (auto* btn : { &btnLoad, &btnPlay , &btnPause, &btnMute, &btnLoop })
    {
        btn->addListener(this);
        addAndMakeVisible(btn);
    }

    volumeControl.setRange(0.0, 1.0, 0.01);
    volumeControl.setValue(0.5);
    volumeControl.addListener(this);
    addAndMakeVisible(volumeControl);

    setSize(600, 250);
}

PlayerGUI::~PlayerGUI()
{
}

void PlayerGUI::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colours::darkgrey);
}

void PlayerGUI::resized()
{
    int y = 20;
    int buttonWidth = 80;
    int spacing = 10;

    btnLoad.setBounds(spacing, y, 100, 40);
    btnPlay.setBounds(btnLoad.getRight() + spacing, y, buttonWidth, 40);
    btnPause.setBounds(btnPlay.getRight() + spacing, y, buttonWidth, 40);
    btnMute.setBounds(btnPause.getRight() + spacing, y, buttonWidth, 40);
    btnLoop.setBounds(btnMute.getRight() + spacing, y, buttonWidth, 40);

    volumeControl.setBounds(spacing, 100, getWidth() - (spacing * 2), 30);
}

void PlayerGUI::buttonClicked(juce::Button* button)
{
    if (button == &btnLoad)
    {
        fileSelector = std::make_unique<juce::FileChooser>(
            "Select an audio file...",
            juce::File{},
            "*.wav;*.mp3");

        fileSelector->launchAsync(
            juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
            [this](const juce::FileChooser& fc)
            {
                auto file = fc.getResult();
                if (file.existsAsFile())
                {
                    audioEngine.loadFile(file);
                    audioEngine.play();
                }
            });
    }

    if (button == &btnPlay)
    {
        audioEngine.play();
    }

    if (button == &btnPause)
    {
        audioEngine.pause();
    }

    if (button == &btnMute)
    {
        audioEngine.toggleMute();
    }

    if (button == &btnLoop)
    {
        audioEngine.toggleLooping();
    }
}

void PlayerGUI::sliderValueChanged(juce::Slider* slider)
{
    if (slider == &volumeControl)
    {
        audioEngine.setGain((float)slider->getValue());
    }
}

void PlayerGUI::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    audioEngine.prepareToPlay(samplesPerBlockExpected, sampleRate);
}
void PlayerGUI::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    audioEngine.getNextAudioBlock(bufferToFill);
}
void PlayerGUI::releaseResources()
{
    audioEngine.releaseResources();
}