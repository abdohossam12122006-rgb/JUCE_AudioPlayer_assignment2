#pragma once
#include <JuceHeader.h>
#include "PlayerAudio.h"

class PlayerGUI : public juce::Component,
    public juce::Button::Listener,
    public juce::Slider::Listener
{
public:
    PlayerGUI();
    ~PlayerGUI() override;

    void paint(juce::Graphics& g) override;
    void resized() override;

    void prepareToPlay(int samplesPerBlockExpected, double sampleRate);
    void getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill);
    void releaseResources();

private:
    PlayerAudio audioEngine;

    juce::TextButton btnLoad{ "Load File" };
    juce::TextButton btnPlay{ "Play" };
    juce::TextButton btnPause{ "Pause" };
    juce::TextButton btnMute{ "Mute" };
    juce::TextButton btnLoop{ "Loop" };

    juce::Slider volumeControl;
    std::unique_ptr<juce::FileChooser> fileSelector;

    void buttonClicked(juce::Button* button) override;
    void sliderValueChanged(juce::Slider* slider) override;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PlayerGUI)
};