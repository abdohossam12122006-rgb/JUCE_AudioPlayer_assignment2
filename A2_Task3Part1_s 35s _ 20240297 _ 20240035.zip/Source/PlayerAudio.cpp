#include "PlayerAudio.h"

PlayerAudio::PlayerAudio()
{
    audioFormats.registerBasicFormats();
}

PlayerAudio::~PlayerAudio()
{
}

void PlayerAudio::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    playerTransport.prepareToPlay(samplesPerBlockExpected, sampleRate);
}

void PlayerAudio::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    playerTransport.getNextAudioBlock(bufferToFill);
}

void PlayerAudio::releaseResources()
{
    playerTransport.releaseResources();
}

bool PlayerAudio::loadFile(const juce::File& file)
{
    if (auto* reader = audioFormats.createReaderFor(file))
    {
        playerTransport.stop();
        playerTransport.setSource(nullptr);
        trackSource.reset();

        trackSource = std::make_unique<juce::AudioFormatReaderSource>(reader, true);

        playerTransport.setSource(trackSource.get(),
            0,
            nullptr,
            reader->sampleRate);
        return true;
    }
    return false;
}

void PlayerAudio::play()
{
    playerTransport.start();
}

void PlayerAudio::pause()
{
    playerTransport.stop();
}

void PlayerAudio::stop()
{
    playerTransport.stop();
    playerTransport.setPosition(0.0);
}

void PlayerAudio::setGain(float gain)
{
    lastVolume = gain;
    if (!isMuted)
    {
        playerTransport.setGain(lastVolume);
    }
}

void PlayerAudio::toggleMute()
{
    isMuted = !isMuted;
    if (isMuted)
    {
        playerTransport.setGain(0.0f);
    }
    else
    {
        playerTransport.setGain(lastVolume);
    }
}

void PlayerAudio::toggleLooping()
{
    if (trackSource != nullptr)
    {
        trackSource->setLooping(!trackSource->isLooping());
    }
}

void PlayerAudio::setPosition(double pos) {}
double PlayerAudio::getPosition() const { return 0.0; }
double PlayerAudio::getLength() const { return 0.0; }